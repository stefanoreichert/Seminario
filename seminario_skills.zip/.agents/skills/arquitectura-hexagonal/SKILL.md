---
name: arquitectura-hexagonal
description: Mantener los límites de la arquitectura hexagonal
---

# Arquitectura hexagonal obligatoria
## Reglas
- Separar Domain, Application, Infrastructure y Presentation/Interfaces.
- Domain contiene entidades, objetos de valor, invariantes y servicios puros. No importa Laravel, Eloquent, HTTP, SQL ni clases de infraestructura.
- Application implementa casos de uso y puertos (interfaces) necesarios; depende únicamente del dominio y de abstracciones propias.
- Infrastructure implementa puertos con persistencia, mensajería y servicios externos; adaptadores encapsulan frameworks.
- Presentation valida y convierte solicitudes/respuestas; controladores delgados, sin reglas de negocio.
- Las dependencias siempre apuntan hacia adentro. Resolver contratos en el contenedor de Laravel.
- Evitar repositorios genéricos obligatorios, abstracciones innecesarias y refactorizaciones globales.
- Antes de agregar una funcionalidad, indicar ubicación de archivos y dependencias.
- Comprobar con pruebas que Domain/Application no dependan de clases framework.
## Referencia de carpetas sugerida
`app/Modules/<Modulo>/{Domain,Application,Infrastructure,Presentation}`. Adaptar a la estructura real ya existente; no imponer migraciones destructivas.
