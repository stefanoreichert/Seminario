# Instalar en el repositorio

1. Descomprimir el ZIP en la raíz del repositorio `C:\xampp\htdocs\Seminario-Stefano-Noelia`, conservando `AGENTS.md` y `.agents/skills/`.
2. Abrir Codex en esa carpeta para que lea `AGENTS.md` y las skills relevantes.
3. Revisar `git status`; después, cuando el equipo lo decida, hacer commit y push.

PowerShell desde la raíz del repositorio, suponiendo ZIP en Descargas:
```powershell
Expand-Archive -Path "$HOME\Downloads\seminario_skills.zip" -DestinationPath . -Force
Get-ChildItem -Force .agents\skills
```

Estas skills son instrucciones de trabajo, no una garantía técnica por sí solas. Añadir pruebas automáticas para detectar incumplimientos de dependencia.
