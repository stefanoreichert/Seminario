# Reglas permanentes — Seminario / SIMON SRL

Proyecto académico de Reichert y Karpe. Sistema de gestión mayorista de calzado de seguridad.

**Regla no negociable:** arquitectura hexagonal: Domain puro; Application orquesta casos de uso y define puertos; Infrastructure adapta persistencia/servicios; Presentation adapta HTTP/UI. Dependencias hacia adentro, controladores delgados, Eloquent fuera del dominio.

Leer antes de editar las skills en `.agents/skills/` que correspondan a la tarea. No modificar arquitectura sin ADR y aprobación explícita. Seguir los requerimientos reales del proyecto; ante documentos contradictorios, señalar diferencias y no convertir suposiciones en código. Probar reglas de negocio y permisos antes de concluir.

Priorizar el TP Análisis para el alcance conservador; comparar el Trabajo Práctico Final Seminario antes de extender funcionalidades. No asumir tecnología o estructura del repositorio sin inspeccionarlo.

Repositorio: https://github.com/stefanoreichert/Seminario
Documentación: https://drive.google.com/drive/folders/1a8ddBrhigHQCwP6oIqDIohcwWSkECmAD
